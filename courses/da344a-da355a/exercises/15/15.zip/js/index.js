document.addEventListener("deviceready", onDeviceReady, false);
function onDeviceReady() {

	// Example notification
	navigator.notification.alert(
		'Welcome to our awesome application!!!',  // message
		alertDismissed,         		// callback
		'Chuck Norris jokes!',            		// title
		'Lets Go!'                  	// buttonName
	);
	
	function alertDismissed(){
		$("body").fadeIn(1000);
	}

	$("#get-joke").on("click", function(){
		load();
		$.ajax({
			url: "http://api.icndb.com/jokes/random",
			data: {
				//firstName: "Anton",
				//lastName: "Tibblin"
				escape: "javascript"
			},
			dataType: "JSON"
		}).done(function(data){
			stopLoad();
			if(data.type == "success"){
				// Example vibrate
				navigator.vibrate(400);
				$("#joke").text(data.value.joke)
				$("#joke").fadeIn(200);
			}
		});
	});
	
	var spinner = new Spinner().spin();
	document.querySelector("#loading").appendChild(spinner.el);
	function load(){
		$("#loading").fadeIn(100);
	}

	function stopLoad(){
		$("#loading").fadeOut(100);
	}
}