$("#menu button").on("click", function() {
    var genre = $(this).attr("id");
    if (genre == "all") {
        $("#movies li").show();
    } else {
        $("#movies li").hide();
        $(`#movies li[data-genre="${genre}"]`).show();
    }
});