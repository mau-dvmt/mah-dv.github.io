$(".section-1").show();

$("menu li").on("click", function() {
    var section = $(this).attr("id");

    $("section").slideUp();
    $(`.${section}`).slideDown();

    $("menu li").removeClass("chosen");
    $(this).addClass("chosen");
});