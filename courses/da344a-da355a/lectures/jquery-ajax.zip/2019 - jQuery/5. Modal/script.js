$("#images img").on("click", function() {
    var imgSrc = $(this).attr("src");
    var imgText = $(this).attr("alt");

    $("body").prepend(`
        <div class="modal">
            <figure>
                <img src="${imgSrc}" alt="${imgText}">
                <figcaption>${imgText}</figcaption>
            </figure>
        </div>
    `);
});

$("body").on("click", ".modal", function() {
    $(this).remove();
});