$("#add-btn").on("click", function() {
    var item = $("#new-item").val();

    $("#items").append(`<li>${item}</li>`);
});