$("#get-tips").on("click", function() {
    $.ajax({
        url: "http://localhost:12345/date.php"
    }).done(function(data) {
        // Om allt går bra
        $("#tips").text(data);
        $("#tips").fadeIn();
    }).fail(function(data) {
        // Om något inte går bra
        console.log(data);
    });
});