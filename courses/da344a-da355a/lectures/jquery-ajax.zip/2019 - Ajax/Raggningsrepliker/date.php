<?php
header('Content-Type: text/html; charset=utf-8');
$jokes = [
	"Jag har låst ute mig själv, vill du hålla mig sällskap?",
	"Du är så söt att mina ögon får diabetes!",
	"Hej, jag har köpt en ny klockradio, skulle du vilja följa med hem och titta på den?",
	"Om jag var en ekorre och du var min nöt, skulle jag äta upp dig för du är så söt",
	"Du och jag passar lika bra ihop som lego.",
	"Tjena kexet, sitter du här och smular?",
	"Jag säger inte det här för att impa på dig, men det är faktiskt jag som är Batman.",
	"-Du är skyldig mig en drink! -Varför då? Jag såg dig och tappade min.",
	"Hej, kom du hit för att träffa en trevlig kille, eller duger jag?",
	"Är du lika rar som filformatet?",
	"Gud måste vara upprörd i kväll, han saknar ju en ängel.",
	"Va unik och annorlunda, säg ja!",
	"Här är jag! Vad är dina två andra önskningar?"
];
echo $jokes[array_rand($jokes)];
?>