$("section").first().show();

$("menu li").on("click", function(){
	if($(this).attr("class") != "chosen"){
		$("menu li").removeClass("chosen");
		$(this).addClass("chosen");
		var section = $(this).attr("id");
		$("section").slideUp();
		$("."+section).slideDown();
	}
});