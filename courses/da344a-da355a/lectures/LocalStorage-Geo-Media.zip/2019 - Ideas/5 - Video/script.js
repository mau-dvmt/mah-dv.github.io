$("#start-movie").on("click", function() {
    $("#movie")[0].play();
});

$("#paus-movie").on("click", function() {
    $("#movie")[0].pause();
})

$("#mute-movie").on("click", function(){
    var video = $("#movie")[0];
    if (video.muted == true) {
        video.muted = false;
    } else {
        video.muted = true;
    }
})