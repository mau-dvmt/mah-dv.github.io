document.cookie = "name=Anton";
document.cookie = "role=Teacher";

console.log(document.cookie);

var now = new Date();
now.setTime(now.getTime() + 3600*1000);
document.cookie = `test=test; expires=${now.toUTCString()}`;

console.log(document.cookie);