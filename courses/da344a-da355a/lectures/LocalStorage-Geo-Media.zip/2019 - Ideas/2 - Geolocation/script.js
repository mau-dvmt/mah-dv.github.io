﻿/*
  Hämtar vår nuvarande plats

  Parametrar:
  - Funktionen: "onSuccess" körs om vi lyckas hitta vår position,
  samt att användaren godkänner att vi tar del av positionen
  - Funktinen: "onFail" körs om vi misslyckas (av någon anledning),
  - Objektet: "{}" ger oss möjlighet att skicka med skicka med
  alternativ till funnktionen.
*/

navigator.geolocation.getCurrentPosition(onSuccess2, onFail, {
  enableHighAccuracy: true, // Försök tvinga enheten till så precis position som möjligt
  timeout: 5000, // Maximal tid (milisekunder) som enheten har på sig att reuturnera positionen
  maximumAge: 0 // Hur länge positionen får cachas (milisekunder)
});

navigator.geolocation.watchPosition(onSuccess, onFail, {
  enableHighAccuracy: true, // Försök tvinga enheten till så precis position som möjligt
  timeout: 5000, // Maximal tid (milisekunder) som enheten har på sig att reuturnera positionen
  maximumAge: 0 // Hur länge positionen får cachas (milisekunder)
});

function onSuccess2(position){
	$("body").append("<img src='https://maps.googleapis.com/maps/api/staticmap?center=" + position.coords.latitude + "," + position.coords.longitude + "&zoom=13&size=300x300&sensor=false'>");
}

function onSuccess(position){
  // "position" är ett objekt som innehåller vår platsinfo
  // Vi loggar var position
  console.log(position);
  $("#location").html("");
  $("#location").append("<p><b>Longitud:</b> " + position.coords.longitude+ "</p>");
  $("#location").append("<p><b>Latitud:</b> " + position.coords.latitude+ "</p>");
  $("#location").append("<p><b>Precision:</b> " + position.coords.accuracy+ "</p>");
  $("#location").append("<p><b>Altitud:</b> " + position.coords.altitude+ "</p>");
  $("#location").append("<p><b>Precision, altitud:</b> " + position.coords.altitudeAccuracy+ "</p>");
  $("#location").append("<p><b>Hastighet:</b> " + position.coords.speed+ "</p>");
}

function onFail(){
  alert("Vi kunde tyvärr inte hämta din plats just nu.");
}