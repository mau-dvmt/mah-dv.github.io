navigator.geolocation.getCurrentPosition(function(position){
    
    var lat = position.coords.latitude;
    var lon = position.coords.longitude;
    var latLang = new google.maps.LatLng(lat, lon);

    var mapProps = {
        center: latLang,
        zoom: 5
    }

    var map = new google.maps.Map(document.querySelector("#googleMap"), mapProps);

    var marker = new google.maps.Marker({
        position: latLang,
        title: "We are here! =)"
    });

    marker.setMap(map);
    
    console.log(position);
}, function(error){
    console.log(error);
}, {
    enableHighAccuracy: true,
    timeout: 5000,
    maximumAge: 0
})