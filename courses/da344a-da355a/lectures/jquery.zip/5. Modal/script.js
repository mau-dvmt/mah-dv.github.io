// När man klickar på en bild i #images
$("#images img").on("click", function() {
	// Hämtar källan från bilden vi klickade på
	var imgSrc = $(this).attr("src");
	// Hämtar alt-texten från bilden vi klickade på
	var imgTitle = $(this).attr("alt");
	
	// Skapar vårt modal-element, tillsammans med bild och bildtext
	$("body").prepend("\
		<div class='modal'>\
			<figure>\
				<img src='"+imgSrc+"' alt='"+imgTitle+"'>\
				<figcaption>"+imgTitle+"</figcaption>\
			</figure>\
		</div>\
	");
});

// När man klickar på en modal (OBS, sättet att skriva nedan innebär att det dynamiskt läggs till en ny event-listener på alla .modal-element när dessa läggs till (även efter att sidan laddats).
$("body").on("click", ".modal", function() {
	// Tar bort elementet vi klickade på
	$(this).remove();
});