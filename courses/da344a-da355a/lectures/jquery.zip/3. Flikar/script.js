// Visar det första section-elementet när sidan laddas
$("section").first().show();

// När man klickar på ett li-element i vår menu
$("menu li").on("click", function() {
	// Tar bort alla "chosen"-klasser från alla li-element i vår menu
	$("menu li").removeClass("chosen");
	// Lägger till "chosen"-klassen på det element som vi klickade på
	$(this).addClass("chosen");
	
	// Letar upp id:t på det element som vi klickade på
	var newSection = $(this).attr("id");
	// Döljer alla section-element
	$("section").slideUp();
	// Visar den section som matchar sin klass, med det id som finns på elementet vi klickade på
	$("."+newSection).slideDown();
});