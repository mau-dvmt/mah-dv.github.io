// När man klickar på något button-element i menu-elementet
$("#menu button").on("click", function (){
	// Kontrollerar om id:t på knappen vi klickar på är "all"
	if ($(this).attr("id") === "all") {
		// Visar alla li-element i #movies (visar alla filmerna)
		$("#movies li").show();
	} else {
		// Döljer alla li-element i #movies (döljer alla filmerna)
		$("#movies li").hide();
		// Letar upp värdet för attributet "id" på elementet vi klickade på
		var genre = $(this).attr("id");
		// Visar upp de filmer som har samma värde i attributet "data-genre" som i variabeln genre
		$("#movies li[data-genre='"+genre+"']").show();
		
		// ex. på ovan (visa bara drama): $("#movies li[data-genre='drama']").show();
		// ex. på ovan (visa bara sci-fi): $("#movies li[data-genre='sci-fi']").show();
	}
});