$(document).on("ready", function (){
	// Kod här körs när sidan har laddats klart
});

$("#add-item").on("click", function() {
	// Körs när man klickar på elementet med id "add-item"
	
	// 1. Leta upp vad användaren skrivit i textrutan
	var item =  $("#new-item").val();
	
	// 2. Kontrollera att det står något i rutan
	if (item === "") {
		// 3.a. Meddela användaren att man måste skriva något i rutan
		alert("Du måste skriva något i rutan!");
	} else {	
		// 3.b. Lägga till den nya saken i listan
		$("#items").append("<li>" + item + "</li>");
	}
});