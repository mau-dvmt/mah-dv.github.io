﻿$("#get-joke").on("click", function(){
	$.ajax({
		url: "http://api.icndb.com/jokes/random",
		dataType: "JSON",
		data: {
			escape: "javascript"
		}
	}).done(function(data){
		$("#joke").text(data.value.joke).fadeIn(500);
	});
});