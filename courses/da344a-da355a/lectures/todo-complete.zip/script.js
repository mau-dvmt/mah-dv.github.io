/*
	Bra att veta:
	
	1) Våra todos sparas i ett objekt, t.ex.
		{
			title: "Rätta inlämningsuppgifter",
			prio: 3
		}
		
	2) Alla våra todos ligger sedan i en lista, t.ex.
		[
			{...},
			{...},
			{...},
			{...}
		]
		
	3) Listan på todos sparas i localStorage, men nyckeln "todos"
	
	4) För att göra en lista med alla todos till JSON använder vi för att spara detta i localStorage.
		JSON.parse(string) // Gör om en sträng till datatyper
		JSON.stringify(data) // Gör om datatyper till strängar
*/

// Ladda in todos, när sidan körs
renderTodos();


function getTodos() {
	// Hämtar alla todos från localStorage
	var todos = localStorage.getItem("todos");
	
	// Kontrollera om det finns några todos i localStorage
	if(todos == null) {
		// Det finns inget i localStorage, så vi skapar en tom lista där
		localStorage.setItem("todos", JSON.stringify([]));
		// Returnerar en tom lista (= inga todos)
		return [];
	} else {
		// Returnerar alla todos i en lista (från JSON => lista med objekt)
		return JSON.parse(todos);
	}
}

function renderTodos(order=false) {
	// Hämtar alla todos
	var todos = getTodos();
	
	/*
		Som stardard sorterar vi inte listan efter prio.
		Men skickar man med true som argument: renderTodos(true)
		så sorterar vi den efter prio istället för kronologiskt.
	*/
	if(order) {
		// Vi sorterar enligt funktionen "compare"
		todos.sort(compare);
	}
	
	// Vi nollställer allt innehåll i vår tabellkropp
	$("#todo-table tbody").html("");

	// För varje todo, i listan av todos
	for (var i = 0; i < todos.length; i++) {
		// Plocka ut aktuell todo från listan
		var todo = todos[i];

		// Lägger till vår todo i <tbody>-elementet i elementet #todo-table
		$("#todo-table tbody").append("\
			<tr class='" + getPrioClass(todo.prio) + "'>\
				<td>" + todo.title + "</td>\
				<td>" + getPrioTitle(todo.prio) + "</td>\
				<td><img src='delete.png' alt='Delete item'></td>\
			</tr>\
		");
	}
}

// När man klickar på tabellrubriken "Prio" så sorterar vi todos efter prio
$("#order-by-prio").on("click", function() {
	renderTodos(true);
});

// När vi "skickar" iväg vårt formulär körs funktionen nedan
$("#todo-form").on("submit", function(e) {
	// Hindrar formulärets standardsbetéende (att skicka iväg data till ny URL)
	e.preventDefault();
	
	// Hämtar texten (titeln) för vår todo (värdet i elementet med id:t "todo")
	var todo = $("#todo").val();
	
	// Validerar så att användaren har angett någon text i textfältet
	if (todo == "") {
		// Om det INTE är okej input (tomt), så visar vi detta
		$("#todo").addClass("is-invalid");
		// ... och avslutar funktionen (då vi inte vill spara en tom todo)
		return false;
	}
	
	// Hämtar värdet för vår prio (1, 2 eller 3)
	var thePrio = $("#prio").val();
	
	// Skapar vårt objekt som representerar en todo-item, men titel & prio som egenskapet
	var newTodo = {
		title: todo,
		prio: thePrio
	}
	
	// Hämtar alla todos från LocalStorage
	var todos = getTodos();
	// Lägger till vår nya todo-item i listan
	todos.push(newTodo);

	// Ersätter våra todos i localStorage med vår uppdaterade lista
	localStorage.setItem("todos", JSON.stringify(todos));
	
	// Återställer vårt formlär (nollstället text-fältet & drop-down menyn)
	$("#todo-form").trigger("reset");
	
	// Renderar om vår tabell, men den uppdaterade listan av todos
	renderTodos();
});

// När användaren ändrar innehållet i vårt textfält med id: todo
$("#todo").on("keyup", function () {
	if($(this).val() == "") {
		// Om textfältet är tomt så visar vi en uppmaning till användaren att fylla i
		$("#todo").addClass("is-invalid");
	} else {
		// Om det finns något skrivit, så tar vi bort uppmaningen.
		$("#todo").removeClass("is-invalid");
	}
})

// När man klickar på "krysset" (bilden för att radera) i tabellen
/*
	$("#todo-table").on("click", "img", function() {
	Raden ovan innebär att "click"-händelsen bevakar alla "img"-element som
	ligger i "todo-table". D.v.s. om det dynamiskt läggs till en bild i 
	"todo-table" (efter att sidan laddats) så kommer click-eventet att fungera
	även på den nya bilden! (vilket är väldigt smidigt!)
*/
$("#todo-table").on("click", "img", function() {
	// Hämta titeln för todo-item (texten i första kolumnen på tabellraden)
	var todoTitle = $(this).parent().prev().prev().text();
	
	// Hämtar alla todos från LocalStorage
	var todos = getTodos();
	
	// Letar upp platsen (index) i listan som vi ska ta bort
	var index = todos.map(function(e) {return e.title}).indexOf(todoTitle);
	
	// Tar bort item från listan (1 innebär att vi tar bort en sak)
	todos.splice(index, 1);
	
	// Ersätter våra todos i localStorage med vår uppdaterade lista
	localStorage.setItem("todos", JSON.stringify(todos));
	
	// Renderar om vår tabell, men den uppdaterade listan av todos
	renderTodos();
});

// Funktion som returerar en textsträng som representerar prion
function getPrioTitle(prio) {
	if(prio == "1") {
		return "Låg";
	} else if (prio == "2") {
		return "Medel";
	} else if (prio == "3") {
		return "Hög";
	} else {
		return "";
	}
}

// Funktion som returerar ett classnamn till vår tabell som representerar prion
function getPrioClass(prio) {
	if(prio == "1") {
		return "table-success";
	} else if (prio == "2") {
		return "table-warning";
	} else if (prio == "3") {
		return "table-danger";
	} else {
		return "";
	}
}

// Funktion som sorterar vår todo.lista erfter prio. Viktigast först
function compare(a, b) {
	if (a.prio > b.prio) {
		return -1;
	}
	if (a.prio < b.prio) {
		return 1;
	}
	return 0;
}