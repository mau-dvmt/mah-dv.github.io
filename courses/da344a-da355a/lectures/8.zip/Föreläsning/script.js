 document.querySelector("#toogle-menu").addEventListener("click", function(){
	 if(window.innerWidth < 480){
		 var menuUl = this.nextElementSibling;
		 if(menuUl.style.display == "none"){
			 menuUl.style.display = "block";
		 }else{
			 menuUl.style.display = "none";
		 }
	 }
 }, false);