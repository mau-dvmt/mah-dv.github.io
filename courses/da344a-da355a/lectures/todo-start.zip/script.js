/*
	Bra att veta:
	
	1) Våra todos sparas i ett objekt, t.ex.
		{
			title: "Rätta inlämningsuppgifter",
			prio: 3
		}
		
	2) Alla våra todos ligger sedan i en lista, t.ex.
		[
			{...},
			{...},
			{...},
			{...}
		]
		
	3) Listan på todos sparas i localStorage, men nyckeln "todos"
	
	4) För att göra en lista med alla todos till JSON använder vi för att spara detta i localStorage.
		JSON.parse(string) // Gör om en sträng till datatyper
		JSON.stringify(data) // Gör om datatyper till strängar
*/

// Ladda in todos, när sidan körs
renderTodos();


function getTodos() {
	// Hämtar alla todos från localStorage
	var todos = localStorage.getItem("todos");
	
	// Kontrollera om det finns några todos i localStorage
	if(todos == null) {
		// Det finns inget i localStorage, så vi skapar en tom lista där
		localStorage.setItem("todos", JSON.stringify([]));
		// Returnerar en tom lista (= inga todos)
		return [];
	} else {
		// Returnerar alla todos i en lista (från JSON => lista med objekt)
		return JSON.parse(todos);
	}
}

function renderTodos() {
	// Hämtar alla todos
	var todos = getTodos();

	// För varje todo, i listan av todos
	for (var i = 0; i < todos.length; i++) {
		// Plocka ut aktuell todo från listan
		var todo = todos[i];

		// Lägger till vår todo i <tbody>-elementet i elementet #todo-table
		$("#todo-table tbody").append("\
			<tr>\
				<td>" + todo.title + "</td>\
				<td>" + todo.prio + "</td>\
			</tr>\
		");
	}
}