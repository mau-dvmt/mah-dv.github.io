function colorize(){
	if(this.className == "movie"){
		this.className = "movie red";
	}else{
		this.className = "movie";
	}
}

var articles = document.querySelectorAll("article");
for(var i = 0; i < articles.length; i++){
	articles[i].addEventListener("click", colorize, false);
}