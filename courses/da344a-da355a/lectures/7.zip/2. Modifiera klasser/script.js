window.onload = start;

function start() {
	var articles = document.querySelectorAll("article");
	for (var i = 0; i < articles.length; i++) {
		articles[i].addEventListener("click", animate, false);
	}
}

function animate() {
	this.className = "movie-card animate";
}