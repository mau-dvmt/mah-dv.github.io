function krToDollar(kr){
	var result = kr/8.7;
	return result;
}

var userInput = prompt("Hur många kr vill du konvertera till dollar?");

if(isNaN(userInput)){
	alert("Du måste ange ett nummer!");
}else{
	var dollar = krToDollar(parseInt(userInput));

	alert(userInput + "kr blir $" + dollar);
}

