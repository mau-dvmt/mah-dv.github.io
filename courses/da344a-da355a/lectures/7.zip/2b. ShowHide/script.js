window.onload = start;

function start() {
	var h2 = document.querySelectorAll("h2");
	for (var i = 0; i < h2.length; i++) {
		h2[i].addEventListener("click", showHide, false);
	}
}

function showHide() {
	var articles = document.querySelectorAll("article");
	for (var i = 0; i < articles.length; i++) {
		articles[i].style.display = "none";
	}
	
	var article = this.nextElementSibling;
	
	article.style.display = "block";
}