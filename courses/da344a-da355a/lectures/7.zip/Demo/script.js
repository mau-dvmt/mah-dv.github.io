 document.querySelector("#kr").addEventListener("keyup", function(){
	 var kr = parseInt(this.value);
	 var result = kr/8.7;
	 document.querySelector("#result").value = result;
 }, false);
 
 
 
 
// Itererar igenom alla element med klassen "show-tooltip"
var toolTipElements = document.querySelectorAll(".show-tooltip");
for(var i = 0; i < toolTipElements.length; i++){
	// När man för muspekaren över ett element med klasses "show-tooltip"
	 toolTipElements[i].addEventListener("mouseover", function(){
		// Skapar ett <div>-element
		var div = document.createElement("div");
		// Tilldelar <div>-elementet klassen "tool-tip"
		div.className = "tool-tip";
		// Skapar en text-nod, men texten som finns i attributet "data-tooltip"
		var text = document.createTextNode(this.getAttribute("data-tooltip"));
		// Lägger till text-noden i vårt <div>-element
		div.appendChild(text);
		// Lägger till <div>-elementet i det element som vi förde muspekaren över
		this.appendChild(div);
	}, false);

	// När man för muspekaren från ett element med klasses "show-tooltip"
	 toolTipElements[i].addEventListener("mouseout", function(){
		// Alla barn till elementet
		var children = this.childNodes;
		// Itererar över alla barnen
		for(var i = 0; i < children.length; i++){
			// Om barnet har klassen "tool-tip" (= vi ska ta bort det)
			if(children[i].className == "tool-tip"){
				// Tar bort vår tool-tip
				this.removeChild(children[i]);
			}
		}
	}, false);
}
