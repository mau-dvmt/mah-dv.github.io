Vue.component('movie', {
    props: ['title'],
    template: '<li class="list-group-item">{{ title }}</li>'
});

var app = new Vue({
    el: '#app',
    data: {
        movies: ["Lady Bird", "The Post", "The Shape of Water"],
        newMovie: ""
    },
    methods: {
        addMovie: function () {
            this.movies.push(this.newMovie);
        }
    }
});


