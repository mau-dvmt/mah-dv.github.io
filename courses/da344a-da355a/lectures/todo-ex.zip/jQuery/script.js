var movies = ["Lady Bird", "The Post", "The Shape of Water"];

$("#add-movie").on("click", function () {
    var movieTitle = $("#new-movie").val();
    movies.push(movieTitle);
    renderMovies();
});

function renderMovies() {
    var movieUL = $("#movies");
    movieUL.html(""); // Reset the list
    $.each(movies, function (i, movie) {
        movieUL.append(`<li class="list-group-item">${movie}</li>`)
    });
}

renderMovies();