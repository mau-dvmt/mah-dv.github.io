function addTodo(){
	// H�mtar todo-item
	var item = document.querySelector("#todo").value;
	// Skapar ett nytt <li>-element och en text-nod
	var li = document.createElement("li");
	var text = document.createTextNode(item);
	// L�gger till text-noden till v�rt <li>-element
	li.appendChild(text);
	// L�gger till <li>-elementet i v�r lista
	document.querySelector("#todoList").appendChild(li);
}

function clearList(){
	// H�mtar <ul>-listan som har alla todo-items
    var itemList = document.querySelector("#todoList");
	// Tar bort att barn till <ul>-listan (t�mmer listan)
    while(itemList.hasChildNodes()){
        itemList.removeChild(itemList.firstChild);
    }
}

function start(){
	// L�gger till "event handlers"
	document.querySelector("#addTodo").onclick = addTodo;
	document.querySelector("#clearList").onclick = clearList;
}

window.onload = start;