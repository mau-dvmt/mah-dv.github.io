function slideShow(){
	// H�mtar den bild som visas nu (bild en med id="show")
	var currentImage = document.querySelector("#show");
	// H�mtar n�sta bild (som ligger efter den bild som visas nu)
	var nextImage = currentImage.nextElementSibling;

	// Kontrollerar s� att det finns en n�sta bild, finns det inte s� b�rjar vi om fr�n b�rjan med f�rsta bilden
	if(nextImage == undefined){
		nextImage = document.querySelector("#slideShow").childNodes[1];
	}
	
	// Tar bort id:t attribut fr�n den bild som visas nu
	currentImage.removeAttribute("id");
	// S�tter id="show" p� den kommande bilden (den som ska visas)
	nextImage.setAttribute("id", "show");
}


function start(){
	// K�r funktionen "slideShow" varannan sekund
	setInterval(slideShow, 2000);
}

window.onload = start;